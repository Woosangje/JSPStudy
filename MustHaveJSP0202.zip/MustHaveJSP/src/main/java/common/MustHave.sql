-- MustHave용으로 사용자 계정을 생성하여 db를 연결하려고 함

create user musthave identified by 1234 ; <!-- 일반 사용자 계정 -->
grant connect, resource to musthave ;  <!-- 권한 부여 -->

-- musthave 계정을 연결하고 Connected인 상태에서 테이블과 자료를 등록
-- 게시판 + 회원용 테이블 생성

create table member(
	id nvarchar2(10) not null,
	pass varchar2(10) not null,
	name nvarchar2(30) not null,
	regidate date default sysdate not null,
	primary key(id)
);
drop table member;

create table board(
	num number primary key,
	title nvarchar2(200) not null,
	content nvarchar2(2000) not null,
	id nvarchar2(20) not null,
	postdate date default sysdate not null,
	visitcount number(6));

alter table board add constraint board_mem_fk foreign key (id) 
references member (id);
<!-- board에다 member를 연결-->

create sequence seq_board_num
	increment by 1
	start with 1
	minvalue 1
	nomaxvalue
	nocycle
	nocache;

drop sequence seq_board_num;
insert into board(num, title, content, id, postdate, visitcount)
values (seq_board_num.nextval, '제목1', '내용1', 'kkw', sysdate, 0);
-- 오류 발생 안됨 (kkw가 member테이블에 없다) -> member테이블에 회원이 있어야 가능



insert into member (id, pass, name) values ('kkw', '1234', '김기원');
insert into member (id, pass, name) values ('ksj', '1234', '김순주');
insert into member (id, pass, name) values ('khj', '1234', '김효진');
insert into member (id, pass, name) values ('kkk', '1234', '김기정');
insert into member (id, pass, name) values ('kkh', '1234', '김기형');
insert into member (id, pass, name) values ('kgw', '1234', '김기운');

insert into board(num, title, content, id, postdate, visitcount)
values(seq_board_num.nextval, '제목1', '내용1', 'kkw', sysdate, 0);
insert into board(num, title, content, id, postdate, visitcount)
values(seq_board_num.nextval, '제목2', '내용2', 'kkw', sysdate, 0);
insert into board(num, title, content, id, postdate, visitcount)
values(seq_board_num.nextval, '제목1', '내용1', 'kkw', sysdate, 0);
insert into board(num, title, content, id, postdate, visitcount)
values(seq_board_num.nextval, '제목1', '내용1', 'kkw', sysdate, 0);
insert into board(num, title, content, id, postdate, visitcount)
values(seq_board_num.nextval, '제목1', '내용1', 'kkw', sysdate, 0);

select * from member;
select * from board;
