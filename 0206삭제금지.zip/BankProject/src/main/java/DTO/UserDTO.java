package DTO;

public class UserDTO {

	int userkey;
	String id;
	String pw;
	String name;
	String accountNumber; //계좌번호
	int blance; //잔액
	
	
	public UserDTO() {
		super();
	}

	public UserDTO(int userkey, String id, String pw, String name, String accountNumber, int blance) {
		super();
		this.userkey = userkey;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.accountNumber = accountNumber;
		this.blance = blance;
	}

	public int getUserkey() {	return userkey;	}

	public String getId() {		return id;		}

	public String getPw() {		return pw;	}

	public String getName() {	return name;	}

	public String getAccountNumber() {	return accountNumber;	}

	public int getBlance() {	return blance;	}

	public void setUserkey(int userkey) {	this.userkey = userkey;	}

	public void setId(String id) {	this.id = id;	}

	public void setPw(String pw) {	this.pw = pw;	}

	public void setName(String name) {	this.name = name;	}

	public void setAccountNumber(String accountNumber) {	this.accountNumber = accountNumber;	}

	public void setBlance(int blance) {	this.blance = blance;	}


	
	
}
