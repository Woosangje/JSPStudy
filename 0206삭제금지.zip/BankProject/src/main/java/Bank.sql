select * from bank_users_table;

select * from test_table;

select * from trades;

select * from USER_TABLE;