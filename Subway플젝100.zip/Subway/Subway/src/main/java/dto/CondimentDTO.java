package dto;

public class CondimentDTO {
	int menuId;
	String conName;
	String conPrice;
	int conCount;// 재고
	String conKind;//종류
	
	public CondimentDTO() {
		super();
	}

	public CondimentDTO(int menuId, String conName, String conPrice, int conCount, String conKind) {
		super();
		this.menuId = menuId;
		this.conName = conName;
		this.conPrice = conPrice;
		this.conCount = conCount;
		this.conKind = conKind;
	}

	public int getMenuId() {return menuId;	}

	public void setMenuId(int menuId) {this.menuId = menuId;	}

	public String getConName() {	return conName;	}

	public void setConName(String conName) {	this.conName = conName;
	}

	public String getConPrice() {
		return conPrice;
	}

	public void setConPrice(String conPrice) {
		this.conPrice = conPrice;
	}

	public int getConCount() {
		return conCount;
	}

	public void setConCount(int conCount) {
		this.conCount = conCount;
	}

	public String getConKind() {
		return conKind;
	}

	public void setConKind(String conKind) {
		this.conKind = conKind;
	}
	
	
}
