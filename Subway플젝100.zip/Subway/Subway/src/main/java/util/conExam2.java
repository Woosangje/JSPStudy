package util;

import dao.CondimentDAO;
import dto.CondimentDTO;

public class conExam {
	CondimentDTO conDTO = new CondimentDTO();
	static CondimentDAO conDAO = new CondimentDAO();
	public static void main(String[] args) {
		

	}

}
