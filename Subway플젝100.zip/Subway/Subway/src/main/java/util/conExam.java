package util;

import java.util.Scanner;

import dao.CondimentDAO;
import dto.CondimentDTO;

public class conExam {
	CondimentDTO conDTO = new CondimentDTO();
	static CondimentDAO conDAO = new CondimentDAO();
	public static void main(String[] args) throws Exception {
		
		System.out.println("1.제품리스트, 2.제품 추가");
		Scanner in = new Scanner(System.in);
		
		switch(in.nextInt()) {
		case 1://제품 리스트
			conDAO.readCondiment();
			break;
		case 2://제품 추가
			
			String conName="conName";
			int conPrice=7777;
			int conCount=1;
			String conKind = "conKind";
			conDAO.insertCondimentDAO(conName , conPrice, conCount, conKind);
			break;
		
		case 3://제품정보수정
			System.out.println("업데이트할 제품번호 입력");
			int menu_id = 33;
			
		}
		
		
		
		
	}	

}
