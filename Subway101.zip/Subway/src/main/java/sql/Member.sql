create table member (
user_id varchar2(20) primary key,
user_pass varchar2(20) not null,
user_name nvarchar2(15) not null,
user_phone varchar2(20) not null,
user_add nvarchar2(100) not null);